# Smash the Patriarchy

A 2D boss-rush game. You play a Black woman who smashes monsters whose bodies are inscribed with oppressive words. Each boss **shatters into the smaller ideas that compose it** — Incel, Red Pill, MGTOW, Pickup Artist for the Manosphere; Maternal Mortality, Pain Dismissal, Reproductive Control for Health Inequality. The game wins not by killing ideas, but by *exposing their anatomy.*

## Run the prototype

```bash
npm install
npm run dev
```

Then open the URL Vite prints (default: http://localhost:5173).

## What's playable

- **Manosphere** is fully built — the boss has 3 HP bars, spawns 4 component creatures on shatter, with full dialogue and the **SOLIDARITY** counter-truth on victory.
- The other 6 bosses (Rape, Work Discrimination, Health Inequality, Motherhood Penalty, Femicide, Gender Essentialism) are selectable as **title-card placeholders** so you can see the full structure.

## The Smasher

**An important design decision:** the Smasher in the prototype is rendered as a **strong, faceless, geometric silhouette** in Afrofuturist armor (red + gold). The "real human photo / art" option the design called for is intentionally **not** generated or stock-sourced in code.

The right path is to **commission a Black artist or photographer and pay them.** Place final assets in:

```
assets/smasher/idle.png
assets/smasher/strike_1.png
assets/smasher/strike_2.png
assets/smasher/strike_3.png
assets/smasher/heavy.png
assets/smasher/dash.png
assets/smasher/hit.png
assets/smasher/victory.png
```

The `Smasher` class in `src/entities/Smasher.js` checks for these files at runtime and falls back to the procedural silhouette if they're missing — so dropping in art is non-breaking.

Same applies to boss portraits and component-creature sprites. The procedural rendering is built to **degrade gracefully**: real art always wins, but the game still looks intentional without it.

## Art direction

Reference points:
- Barbara Kruger (typography, red/black/white)
- Emory Douglas / Black Panther posters (flat color, defiance)
- Afrofuturist armor (geometric, ceremonial)
- Risograph print (slight misregistration, grain)

Palette lives in `src/style/palette.js`:
- Paper `#f3ecdf`
- Ink `#1a1414`
- Blood `#c81d2a`
- Gold `#d4a017`
- Cobalt `#1a3a8a`

## Audio

All synthesized via the Web Audio API. Drums are layered shekere/conga/body-slap hits; component-creature deaths chime like bells; the boss theme mutates per phase. The music tempo increases as the boss loses HP bars.

If you want to swap in real audio, drop files into `assets/audio/` and override the URLs in `src/audio/AudioEngine.js`.

## File map

```
src/
  main.js                  Entry point
  config.js                Phaser game config
  style/
    palette.js             Colors
    riso.js                Risograph misregistration & grain
    type.js                Bold typography helpers
  audio/
    AudioEngine.js         Web Audio synth
  entities/
    Smasher.js             Player character
    Boss.js                Boss base class
    Component.js           Component creature base class
  scenes/
    BootScene.js
    TitleScene.js
    LevelSelectScene.js
    GameScene.js           Main arena scene
    PlaceholderScene.js    For the 6 not-yet-built levels
    VictoryScene.js
  data/
    bosses.js              All 7 boss definitions
  ui/
    HUD.js
```

## Status

Prototype. One full level, six placeholders, procedural art and audio. Designed to demo the loop, the tone, and the feeling of breaking words apart.
