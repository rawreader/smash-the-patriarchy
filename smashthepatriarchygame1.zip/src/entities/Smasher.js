// The Smasher.
//   Body:  procedural Afrofuturist geometric figure (red + gold armor, cape).
//   Head:  a real painting by Rebecca Wanzo, layered onto the faceless silhouette
//          so the player sees a real woman's face inside the armor she made for herself.
//
//   Sourcing the head: assets/smasher/idle.png. If absent, we fall back to a
//   faceless geometric head. No other poses are required for the prototype —
//   the painting is a portrait and is used as the head in every state.

import Phaser from 'phaser';
import { PALETTE, FONT } from '../style/palette.js';

const STATE = {
  IDLE: 'idle',
  WALK: 'walk',
  STRIKE: 'strike',
  HEAVY: 'heavy',
  DASH: 'dash',
  HIT: 'hit',
  BLOCK: 'block',
  VICTORY: 'victory',
};

export class Smasher {
  constructor(scene, x, y) {
    this.scene = scene;
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.facing = 1; // 1 = right, -1 = left
    this.state = STATE.IDLE;
    this.stateT = 0;
    this.hp = 100;
    this.maxHp = 100;
    this.strikeCombo = 0;
    this.strikeTimer = 0;
    this.dashTimer = 0;
    this.dashCooldown = 0;
    this.iFrames = 0;
    this.invuln = 0;
    this.truthMeter = 0;
    this.truthBombs = 1;
    this.hasPainting = scene.textures.exists('smasher_idle');

    this.container = scene.add.container(x, y);
    this._buildVisual();

    this.body = {
      w: 36, h: 78,
      get left()   { return this.x - this.w / 2; },
      get right()  { return this.x + this.w / 2; },
      get top()    { return this.y - this.h; },
      get bottom() { return this.y; },
    };

    this.strikeHB = { active: false, x: 0, y: 0, w: 60, h: 60, damage: 0, hasHit: new Set() };
    this.heavyHB  = { active: false, x: 0, y: 0, w: 80, h: 80, damage: 0, hasHit: new Set() };
  }

  _buildVisual() {
    this.shadow = this.scene.add.ellipse(0, 46, 50, 14, 0x1a1414, 0.25);
    this.container.add(this.shadow);

    // Body
    this._buildBody();

    // Head
    if (this.hasPainting) {
      this._buildPaintedHead();
    } else {
      this._buildFacelessHead();
    }
  }

  _buildBody() {
    // Cape — drawn first so body covers it.
    const cape = this.scene.add.graphics();
    cape.fillStyle(parseInt(PALETTE.bloodDeep.replace('#','16'), 16), 0.85);
    cape.beginPath();
    cape.moveTo(-22, -20);
    cape.lineTo(22, -20);
    cape.lineTo(38, 70);
    cape.lineTo(-38, 70);
    cape.closePath();
    cape.fillPath();
    this.container.add(cape);
    this.cape = cape;

    this.gfx = this.scene.add.graphics();
    this.container.add(this.gfx);

    // Legs
    this.gfx.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    this.gfx.fillRect(-18, 10, 14, 36);
    this.gfx.fillRect(4, 10, 14, 36);

    // Boots
    this.gfx.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.gfx.fillRect(-20, 38, 18, 10);
    this.gfx.fillRect(2, 38, 18, 10);

    // Torso
    this.gfx.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    this.gfx.beginPath();
    this.gfx.moveTo(-30, -18);
    this.gfx.lineTo(30, -18);
    this.gfx.lineTo(24, 18);
    this.gfx.lineTo(-24, 18);
    this.gfx.closePath();
    this.gfx.fillPath();

    // Chest plate
    this.gfx.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.gfx.fillRect(-10, -12, 20, 18);
    this.gfx.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    this.gfx.fillRect(-3, -10, 6, 14);

    // Pauldrons
    this.gfx.fillStyle(parseInt(PALETTE.goldLight.replace('#','16'), 16), 1);
    this.gfx.fillCircle(-30, -18, 10);
    this.gfx.fillCircle(30, -18, 10);

    // Arms
    this.gfx.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    this.gfx.fillRect(24, -16, 12, 32);
    this.gfx.fillRect(-36, -16, 12, 32);

    // Fists
    this.gfx.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.gfx.fillCircle(36, 16, 9);
    this.gfx.fillCircle(-36, 16, 9);

    // Neck (still there as a connector, but smaller if we have a portrait)
    this.gfx.fillStyle(parseInt(PALETTE.cobaltLight.replace('#','16'), 16), 1);
    this.gfx.fillRect(-5, -26, 10, 8);

    // Strike flash
    this.strikeFlash = this.scene.add.circle(0, 0, 0, parseInt(PALETTE.gold.replace('#','16'), 16), 0.5);
    this.strikeFlash.setVisible(false);
    this.container.add(this.strikeFlash);
  }

  _buildPaintedHead() {
    // Rebecca's painting. Layered ABOVE the cape & body, framed with a gold headband.
    // The head is centered slightly above the body. We render the painting as a
    // sprite so it can be flipped when the Smasher faces left.
    this.head = this.scene.add.sprite(0, -44, 'smasher_idle');
    // Painting is 512x512. We want it to be ~60px wide on the body — same scale as the
    // faceless head (~30px wide, 36px tall). Scale down.
    this.head.setDisplaySize(64, 64);
    this.head.setOrigin(0.5, 0.5);
    this.container.add(this.head);

    // A gold "crown band" overlay so the head reads as wearing armor.
    this.crown = this.scene.add.graphics();
    this.crown.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.crown.fillRect(-18, -76, 36, 6);
    // Red gem in center
    this.crown.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    this.crown.fillRect(-3, -78, 6, 10);
    this.container.add(this.crown);
  }

  _buildFacelessHead() {
    // Fallback: faceless geometric head (used only if painting is absent).
    this.head = this.scene.add.graphics();
    // Neck
    this.head.fillStyle(parseInt(PALETTE.cobaltLight.replace('#','16'), 16), 1);
    this.head.fillRect(-6, -28, 12, 12);
    // Head oval
    this.head.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    this.head.fillEllipse(0, -42, 26, 32);
    // Crown
    this.head.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.head.fillRect(-14, -56, 28, 8);
    this.head.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    this.head.fillRect(-4, -58, 8, 12);
    this.container.add(this.head);
  }

  setState(s) {
    this.state = s;
    this.stateT = 0;
  }

  update(input, dt) {
    this.stateT += dt;
    this.strikeTimer = Math.max(0, this.strikeTimer - dt);
    this.dashTimer = Math.max(0, this.dashTimer - dt);
    this.dashCooldown = Math.max(0, this.dashCooldown - dt);
    this.iFrames = Math.max(0, this.iFrames - dt);
    this.invuln = Math.max(0, this.invuln - dt);

    if (this.cape) {
      this.cape.rotation = Math.sin(this.scene.time.now / 200) * 0.04;
    }

    if (this.state === STATE.HIT) {
      if (this.stateT > 0.3) this.setState(STATE.IDLE);
    } else if (this.state === STATE.STRIKE) {
      if (this.stateT > 0.18) {
        this.setState(STATE.IDLE);
        this.strikeHB.active = false;
      } else {
        if (this.stateT > 0.10 && input.strikePressed && this.strikeCombo < 3) {
          this.strikeCombo++;
          this._beginStrike();
        }
      }
    } else if (this.state === STATE.HEAVY) {
      if (this.stateT > 0.4) {
        this.setState(STATE.IDLE);
        this.heavyHB.active = false;
      }
    } else if (this.state === STATE.DASH) {
      this.x += this.vx * dt;
      if (this.dashTimer <= 0) {
        this.setState(STATE.IDLE);
        this.vx = 0;
      }
    } else if (this.state === STATE.BLOCK) {
      if (!input.blockHeld) this.setState(STATE.IDLE);
    } else if (this.state === STATE.VICTORY) {
      this.container.y = this.y + Math.sin(this.scene.time.now / 250) * 3;
    } else {
      let moveX = 0;
      if (input.left)  moveX -= 1;
      if (input.right) moveX += 1;
      if (moveX !== 0) {
        this.facing = moveX > 0 ? 1 : -1;
        this.x += moveX * 230 * dt;
        this.setState(STATE.WALK);
      } else {
        this.setState(STATE.IDLE);
      }
      this.vx = moveX * 230;

      if (input.strikePressed && this.strikeTimer <= 0) {
        this.strikeCombo = 1;
        this._beginStrike();
      }
      if (input.heavyPressed) this._beginHeavy();
      if (input.dashPressed && this.dashCooldown <= 0) this._beginDash();
      if (input.blockPressed) this.setState(STATE.BLOCK);
      if (input.truthBombPressed && this.truthBombs > 0) this._fireTruthBomb();
    }

    this.x = Phaser.Math.Clamp(this.x, 60, 1220);

    if (this.strikeHB.active) {
      this.strikeHB.x = this.x + this.facing * 36;
      this.strikeHB.y = this.y - 30;
    }
    if (this.heavyHB.active) {
      this.heavyHB.x = this.x + this.facing * 40;
      this.heavyHB.y = this.y - 40;
    }

    this.container.setPosition(this.x, this.y);
    this.container.setFlipX(this.facing === -1);
    if (this.state !== STATE.VICTORY) this.container.y = this.y;

    // I-frame visual: blink head/body
    if (this.iFrames > 0 && Math.floor(this.iFrames * 20) % 2 === 0) {
      this.container.setAlpha(0.4);
    } else {
      this.container.setAlpha(1);
    }
  }

  _beginStrike() {
    this.setState(STATE.STRIKE);
    this.strikeTimer = 0.35;
    this.strikeHB.active = true;
    this.strikeHB.damage = 8 + this.strikeCombo * 2;
    this.strikeHB.hasHit.clear();
    this.scene.time.delayedCall(60, () => { this.strikeHB.active = false; });
    if (this.strikeFlash) {
      this.strikeFlash.setVisible(true);
      this.strikeFlash.setPosition(this.facing * 36, -30);
      this.strikeFlash.setRadius(0);
      this.scene.tweens.add({
        targets: this.strikeFlash,
        radius: 36,
        alpha: 0,
        duration: 200,
        onComplete: () => this.strikeFlash.setVisible(false),
      });
    }
    const kinds = ['shekere', 'conga', 'slap'];
    this.scene.audio.hit(kinds[this.strikeCombo - 1] || 'slap', 0.8 + this.strikeCombo * 0.1);
  }

  _beginHeavy() {
    this.setState(STATE.HEAVY);
    this.heavyHB.active = true;
    this.heavyHB.damage = 22;
    this.heavyHB.hasHit.clear();
    this.scene.time.delayedCall(140, () => { this.heavyHB.active = false; });
    this.scene.audio.hit('conga', 1.0);
  }

  _beginDash() {
    this.setState(STATE.DASH);
    this.dashTimer = 0.18;
    this.dashCooldown = 0.5;
    this.vx = this.facing * 600;
    this.iFrames = 0.2;
  }

  _fireTruthBomb() {
    this.truthBombs = 0;
    this.scene.events.emit('truth-bomb', { x: this.x, y: this.y, facing: this.facing });
    this.scene.audio.truthBomb();
    this.scene.cameras.main.flash(120, 212, 160, 23, false);
  }

  takeDamage(amount, fromX = 0) {
    if (this.iFrames > 0) return false;
    if (this.state === STATE.BLOCK) {
      this.scene.events.emit('parry', { fromX, y: this.y });
      this.scene.audio.chime(1200);
      this.truthMeter = Math.min(100, this.truthMeter + 8);
      if (this.truthMeter >= 100 && this.truthBombs === 0) {
        this.truthBombs = 1;
        this.truthMeter = 0;
      }
      return false;
    }
    this.hp = Math.max(0, this.hp - amount);
    this.setState(STATE.HIT);
    this.iFrames = 0.6;
    this.scene.audio.playerHit();
    this.scene.cameras.main.shake(180, 0.012);
    if (this.hp <= 0) {
      this.hp = 1;
      this.truthBombs = 1;
      this.truthMeter = 0;
      this.scene.cameras.main.flash(400, 200, 29, 42, false);
      this.scene.events.emit('death-defied');
    }
    return true;
  }

  gainTruth(amount) {
    this.truthMeter = Math.min(100, this.truthMeter + amount);
    if (this.truthMeter >= 100 && this.truthBombs === 0) {
      this.truthBombs = 1;
      this.truthMeter = 0;
    }
  }

  setVictory() {
    this.setState(STATE.VICTORY);
  }
}

Smasher.STATE = STATE;
