// Smash the Patriarchy — visual palette
// Bold poster-art. Off-white paper, deep ink, blood red, gold accent, cobalt shadow.

export const PALETTE = {
  paper:      '#f3ecdf',
  paperDark:  '#e6dccb',
  ink:        '#1a1414',
  inkSoft:    '#2a2222',
  blood:      '#c81d2a',
  bloodDeep:  '#8a0e1a',
  bloodLight: '#e85a64',
  gold:       '#d4a017',
  goldLight:  '#f0c148',
  cobalt:     '#1a3a8a',
  cobaltLight:'#3d5fb3',
  cream:      '#f7f1e3',
  shadow:     'rgba(26, 20, 20, 0.55)',
};

export const FONT = {
  display: "'Anton', 'Bebas Neue', Impact, sans-serif",
  body:    "'Space Mono', 'Courier New', monospace",
};
