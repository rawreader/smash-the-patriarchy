// Risograph-style misregistration & grain.
// Cheap, runs at startup, applied as overlays and procedural noise on shapes.

import { PALETTE } from './palette.js';

// Generate a small grayscale noise texture once.
// We use it to break up flat shapes and to overlay on UI elements.
let _noiseTexture = null;

export function getNoiseTexture(scene, size = 256) {
  if (_noiseTexture && !scene.textures.exists('__risoNoise')) {
    _noiseTexture = null;
  }
  if (_noiseTexture) return _noiseTexture;

  const key = '__risoNoise';
  if (scene.textures.exists(key)) {
    _noiseTexture = key;
    return _noiseTexture;
  }

  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(size, size);
  for (let i = 0; i < img.data.length; i += 4) {
    // Sparse dark grain, like riso ink flecks.
    const v = Math.random() < 0.08 ? Math.floor(Math.random() * 60) : 0;
    img.data[i]     = v;
    img.data[i + 1] = v;
    img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  scene.textures.addCanvas(key, canvas);
  _noiseTexture = key;
  return _noiseTexture;
}

// Draw a shape with a slight chromatic misregistration —
// like a riso print where the red and black plates don't quite line up.
// Use this in place of normal fillRect for big flat shapes.
export function drawRisoRect(scene, g, x, y, w, h, color, offset = 2, alpha = 1) {
  const [r, gC, b] = parseColor(color);
  // Soft "shadow plate" in a complementary ink
  g.fillStyle(`rgba(${Math.floor(r * 0.4)}, ${Math.floor(gC * 0.4)}, ${Math.floor(b * 0.4)}, ${alpha * 0.6})`, 1);
  g.fillRect(x - offset, y - offset, w, h);
  // Main plate
  g.fillStyle(color, alpha);
  g.fillRect(x, y, w, h);
}

// Apply grain overlay to a graphics object — call after drawing shapes.
export function applyGrain(scene, g, alpha = 0.08) {
  const key = getNoiseTexture(scene);
  g.fillStyle(key, alpha);
  // Cover the same area; caller should set g.beginDraw() bounds via fillRect.
  // We can't know bounds here, so this is mostly a no-op stub —
  // we use it as a marker. See the helper `withGrain` below.
}

function parseColor(hex) {
  if (hex.startsWith('rgb')) {
    return hex.match(/\d+/g).map(Number).slice(0, 3);
  }
  const h = hex.replace('#', '');
  return [
    parseInt(h.substring(0, 2), 16),
    parseInt(h.substring(2, 4), 16),
    parseInt(h.substring(4, 6), 16),
  ];
}
