// Bold typography helpers — brutalist, all-caps, big.
// We draw with Phaser's text on a Graphics object to keep style consistent.

import { PALETTE, FONT } from './palette.js';

// Draw a stack of broken letters: the word, slightly broken across
// horizontal cracks. Used on bosses & components.
export function drawBrokenWord(scene, g, text, x, y, options = {}) {
  const {
    color = PALETTE.ink,
    shadowColor = PALETTE.blood,
    fontSize = 64,
    fontFamily = FONT.display,
    align = 'center',
    offset = 3,
  } = options;

  // Shadow plate (riso misregistration)
  g.textStyle = { fontFamily, fontSize, color: shadowColor, fontStyle: 'bold' };

  // Phaser Graphics supports `text` via add.text, not on Graphics.
  // So this helper returns the text config; callers add it as a child.
  return {
    x, y,
    text,
    style: {
      fontFamily,
      fontSize: `${fontSize}px`,
      color,
      fontStyle: 'bold',
      align,
      strokeThickness: 0,
      shadow: {
        offsetX: offset,
        offsetY: offset,
        color: shadowColor,
        blur: 0,
        fill: true,
      },
    },
  };
}

// A big poster headline: word + an underline block in blood red.
export function headlineStyle(text, size = 96) {
  return {
    fontFamily: FONT.display,
    fontSize: `${size}px`,
    color: PALETTE.ink,
    fontStyle: 'bold',
  };
}
