// Procedural audio: drums (shekere/conga/body-slap), bell chimes, ambient music.
// Web Audio API only. No samples. Designed so the prototype feels alive.

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.musicNodes = null;
    this.musicTempo = 110; // BPM, base
    this.musicIntensity = 1; // 1..3, increases per phase
    this.musicTimer = null;
    this._nextStep = 0;
    this._step = 0;
    this._initialized = false;
  }

  // AudioContext must be created on a user gesture.
  init() {
    if (this._initialized) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.7;
    this.master.connect(this.ctx.destination);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.45;
    this.musicGain.connect(this.master);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = 0.85;
    this.sfxGain.connect(this.master);

    this._initialized = true;
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }

  // --- SFX ---------------------------------------------------------------

  // Hand percussion hit. 'kind' is one of: shekere, conga, slap, kick.
  hit(kind = 'shekere', power = 1) {
    if (!this._initialized) return;
    const t = this.ctx.currentTime;
    if (kind === 'kick') {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(140, t);
      o.frequency.exponentialRampToValueAtTime(45, t + 0.18);
      g.gain.setValueAtTime(0.001, t);
      g.gain.exponentialRampToValueAtTime(0.9 * power, t + 0.005);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
      o.connect(g).connect(this.sfxGain);
      o.start(t); o.stop(t + 0.3);
      return;
    }

    // Shekere / conga / slap: noise + filtered body.
    const dur = kind === 'slap' ? 0.08 : 0.18;
    const bodyFreq = kind === 'conga' ? 220 : kind === 'slap' ? 480 : 380;

    // Body: pitched oscillator with quick decay.
    const o = this.ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.setValueAtTime(bodyFreq, t);
    o.frequency.exponentialRampToValueAtTime(bodyFreq * 0.5, t + dur);
    const og = this.ctx.createGain();
    og.gain.setValueAtTime(0.001, t);
    og.gain.exponentialRampToValueAtTime(0.55 * power, t + 0.004);
    og.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(og).connect(this.sfxGain);
    o.start(t); o.stop(t + dur + 0.05);

    // Noise: short burst, band-passed.
    const bufferSize = Math.floor(this.ctx.sampleRate * dur);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    }
    const n = this.ctx.createBufferSource();
    n.buffer = buffer;
    const filt = this.ctx.createBiquadFilter();
    filt.type = kind === 'slap' ? 'highpass' : 'bandpass';
    filt.frequency.value = bodyFreq * 1.5;
    filt.Q.value = 4;
    const ng = this.ctx.createGain();
    ng.gain.value = 0.3 * power;
    n.connect(filt).connect(ng).connect(this.sfxGain);
    n.start(t);
  }

  // A bright bell — used when a component creature dies.
  chime(root = 880) {
    if (!this._initialized) return;
    const t = this.ctx.currentTime;
    const partials = [1, 2.01, 3.02, 4.7];
    partials.forEach((mult, i) => {
      const o = this.ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = root * mult;
      const g = this.ctx.createGain();
      const a = 0.18 / (i + 1);
      g.gain.setValueAtTime(0.001, t);
      g.gain.exponentialRampToValueAtTime(a, t + 0.005);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.9 + i * 0.05);
      o.connect(g).connect(this.sfxGain);
      o.start(t); o.stop(t + 1.1);
    });
  }

  // Heavy "crack" — boss phase break.
  crack() {
    if (!this._initialized) return;
    const t = this.ctx.currentTime;
    // Sub thump.
    const o = this.ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(120, t);
    o.frequency.exponentialRampToValueAtTime(30, t + 0.5);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(1.0, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    o.connect(g).connect(this.master);
    o.start(t); o.stop(t + 0.65);

    // White-noise burst.
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.3);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const n = this.ctx.createBufferSource();
    n.buffer = buffer;
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(2000, t);
    filt.frequency.exponentialRampToValueAtTime(200, t + 0.3);
    const ng = this.ctx.createGain();
    ng.gain.setValueAtTime(0.5, t);
    ng.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    n.connect(filt).connect(ng).connect(this.master);
    n.start(t);
  }

  // Counter-truth reveal — warm, ascending triad in gold.
  reveal() {
    if (!this._initialized) return;
    const t = this.ctx.currentTime;
    const notes = [392, 494, 587, 784]; // G, B, D, G
    notes.forEach((f, i) => {
      const start = t + i * 0.09;
      const o = this.ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = f;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.001, start);
      g.gain.exponentialRampToValueAtTime(0.22, start + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, start + 1.8);
      o.connect(g).connect(this.master);
      o.start(start); o.stop(start + 1.9);
    });
  }

  // Truth Bomb — a big synth swell, the Smasher's screen-clearing special.
  truthBomb() {
    if (!this._initialized) return;
    const t = this.ctx.currentTime;
    // Two oscillators forming a perfect fifth rising.
    [0, 7].forEach((semi, i) => {
      const o = this.ctx.createOscillator();
      o.type = i === 0 ? 'sawtooth' : 'square';
      const base = 110 * Math.pow(2, semi / 12);
      o.frequency.setValueAtTime(base, t);
      o.frequency.exponentialRampToValueAtTime(base * 2, t + 0.6);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.001, t);
      g.gain.exponentialRampToValueAtTime(0.5, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.9);
      const filt = this.ctx.createBiquadFilter();
      filt.type = 'lowpass';
      filt.frequency.setValueAtTime(800, t);
      filt.frequency.exponentialRampToValueAtTime(4000, t + 0.5);
      o.connect(filt).connect(g).connect(this.master);
      o.start(t); o.stop(t + 1.0);
    });
  }

  // Player hit.
  playerHit() {
    if (!this._initialized) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(220, t);
    o.frequency.exponentialRampToValueAtTime(80, t + 0.25);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(0.4, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g).connect(this.master);
    o.start(t); o.stop(t + 0.35);
  }

  // --- Music -------------------------------------------------------------

  // Start a drum-forward loop. Intensity 1..3 mutates density & tempo.
  startMusic() {
    if (!this._initialized) return;
    this.stopMusic();
    this.musicIntensity = 1;
    this.musicTempo = 110;
    this._step = 0;
    const stepMs = (60 / this.musicTempo) * 1000 / 2; // 8th notes
    this.musicTimer = setInterval(() => this._tick(), stepMs);
  }

  setIntensity(level) {
    this.musicIntensity = Math.max(1, Math.min(3, level));
    // Tempo rises with intensity.
    this.musicTempo = 100 + (level - 1) * 15;
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      const stepMs = (60 / this.musicTempo) * 1000 / 2;
      this.musicTimer = setInterval(() => this._tick(), stepMs);
    }
  }

  stopMusic() {
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  _tick() {
    if (!this._initialized) return;
    // 16-step pattern. Kick on 1,5,9,13. Conga on 3,7,11,15. Shekere varies.
    const s = this._step % 16;

    // Kick drum
    if ([0, 4, 8, 12].includes(s)) {
      this._kick(0.85);
    }
    // Snare-ish body on 4, 12
    if (s === 4 || s === 12) this._body(0.7);
    if (s === 12 && this.musicIntensity >= 2) this._body(0.6);

    // Conga / shekere on off-beats
    if ([2, 6, 10, 14].includes(s)) this._conga(0.5);
    if (s === 6 || s === 14) this._conga(0.7);

    // Shekere shimmer, density scales with intensity
    const shekereDensity = [0, 1, 3, 5][this.musicIntensity];
    if (s % 2 === 1 && (s % (shekereDensity + 1) === 0)) {
      this._shekere(0.25);
    }

    // Bassline pulse every 4 steps
    if (s % 4 === 0) this._bass(0.4);

    // Brass stab at intensity 3 every 8 steps
    if (this.musicIntensity >= 3 && s % 8 === 0) this._stab();

    this._step++;
  }

  _kick(v) {
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(140, t);
    o.frequency.exponentialRampToValueAtTime(45, t + 0.16);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(v, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
    o.connect(g).connect(this.musicGain);
    o.start(t); o.stop(t + 0.25);
  }

  _body(v) {
    const t = this.ctx.currentTime;
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.15);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const n = this.ctx.createBufferSource();
    n.buffer = buffer;
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.frequency.value = 200;
    filt.Q.value = 1.2;
    const g = this.ctx.createGain();
    g.gain.value = v * 0.6;
    n.connect(filt).connect(g).connect(this.musicGain);
    n.start(t);
  }

  _conga(v) {
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.setValueAtTime(260, t);
    o.frequency.exponentialRampToValueAtTime(140, t + 0.13);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(v, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    o.connect(g).connect(this.musicGain);
    o.start(t); o.stop(t + 0.2);
  }

  _shekere(v) {
    const t = this.ctx.currentTime;
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.07);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const n = this.ctx.createBufferSource();
    n.buffer = buffer;
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'highpass';
    filt.frequency.value = 3500;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    n.connect(filt).connect(g).connect(this.musicGain);
    n.start(t);
  }

  _bass(v) {
    const t = this.ctx.currentTime;
    const root = this.musicIntensity >= 2 ? 73.4 : 65.4; // D2 or C2
    const o = this.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.value = root;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(v * 0.6, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.value = 250;
    o.connect(filt).connect(g).connect(this.musicGain);
    o.start(t); o.stop(t + 0.55);
  }

  _stab() {
    const t = this.ctx.currentTime;
    [220, 277, 330].forEach((f) => {
      const o = this.ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = f;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.001, t);
      g.gain.exponentialRampToValueAtTime(0.18, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
      const filt = this.ctx.createBiquadFilter();
      filt.type = 'lowpass';
      filt.frequency.value = 1800;
      o.connect(filt).connect(g).connect(this.musicGain);
      o.start(t); o.stop(t + 0.35);
    });
  }
}
