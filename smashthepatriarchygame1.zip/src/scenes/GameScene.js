// Main arena scene. Loads a boss, spawns the Smasher, runs the fight.
// Manosphere is fully implemented; the structure is generic enough to host
// any of the 7 bosses once they get Boss subclasses or behaviors.

import Phaser from 'phaser';
import { PALETTE, FONT } from '../style/palette.js';
import { BOSSES } from '../data/bosses.js';
import { Smasher } from '../entities/Smasher.js';
import { Boss } from '../entities/Boss.js';
import { Component } from '../entities/Component.js';

export class GameScene extends Phaser.Scene {
  constructor() { super('Game'); }

  init(data) {
    this.bossId = data.bossId || 'manosphere';
  }

  create() {
    const { width, height } = this.scale;
    this.cameras.main.setBackgroundColor(PALETTE.paper);

    this.bossDef = BOSSES.find(b => b.id === this.bossId) || BOSSES[0];
    this.audio = this.game.audio;
    this.audio.setIntensity(1);
    this.audio.startMusic();

    // Arena backdrop — bold geometric poster composition
    this._buildArena(width, height);

    // Player
    this.smasher = new Smasher(this, 200, 520);
    this.smasher.body.bottom = 540;
    this.smasher.y = 540;

    // Boss — placed to the right
    this.boss = new Boss(this, this.bossDef, 1000, 380);
    this.bosses = [this.boss];

    // Components & projectiles
    this.components = [];
    this.projectiles = []; // boss & component shots
    this.smashFx = []; // visual particles

    // HUD
    this._buildHUD(width, height);

    // Input
    this.input = {
      left: false, right: false, up: false, down: false,
      strikePressed: false, heavyPressed: false, dashPressed: false,
      blockHeld: false, blockPressed: false, truthBombPressed: false,
    };
    this._wireInput();

    // Listen for spawned components & projectiles
    this.events.on('component-spawned', (c) => this.components.push(c));
    this.events.on('component-killed', ({ word }) => {
      this.smasher.gainTruth(20);
      this._flashCounterTruth(word, 700);
    });
    this.events.on('boss-shoot', ({ text, x, y, dir, damage }) => {
      this._spawnProjectile(text, x, y, dir, damage, PALETTE.ink, 28);
    });
    this.events.on('component-shoot', ({ text, x, y, dir, damage }) => {
      this._spawnProjectile(text, x, y, dir, damage, PALETTE.blood, 18);
    });
    this.events.on('truth-bomb', () => this._truthBombFx());
    this.events.on('parry', () => this._parryFx());
    this.events.on('death-defied', () => this._deathDefiedFx());

    // Taunt intro
    this.time.delayedCall(500, () => {
      this.boss._taunt('You don\'t belong here.');
    });
  }

  _buildArena(w, h) {
    // Floor
    const floor = this.add.graphics();
    floor.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    floor.fillRect(0, 540, w, 4);
    // Floor shadow stripe
    floor.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 0.5);
    floor.fillRect(0, 544, w, 80);

    // Big poster words in the background
    const bg = this.add.graphics();
    bg.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 0.08);
    bg.fillRect(0, 0, w, 540);

    // Arena motif varies per boss
    this._buildArenaMotif();

    // Top HUD strip
    const strip = this.add.graphics();
    strip.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    strip.fillRect(0, 0, w, 64);
    strip.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    strip.fillRect(0, 64, w, 4);
  }

  _buildArenaMotif() {
    // Manosphere: glowing screens. For others, different motifs.
    if (this.bossId === 'manosphere') {
      for (let i = 0; i < 5; i++) {
        const x = 100 + i * 240;
        const y = 120 + (i % 2) * 100;
        const w = 180, ht = 110;
        const screen = this.add.graphics();
        screen.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
        screen.fillRect(x, y, w, ht);
        screen.fillStyle(parseInt(PALETTE.cobalt.replace('#','16'), 16), 1);
        screen.fillRect(x + 4, y + 4, w - 8, ht - 8);
        // "speech"
        for (let l = 0; l < 5; l++) {
          const len = 40 + Math.random() * 100;
          screen.fillStyle(parseInt(PALETTE.cream.replace('#','16'), 16), 0.6);
          screen.fillRect(x + 14, y + 18 + l * 16, len, 4);
        }
      }
    } else if (this.bossId === 'rape') {
      // Courthouse — columns
      for (let i = 0; i < 4; i++) {
        const x = 150 + i * 280;
        const col = this.add.graphics();
        col.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
        col.fillRect(x, 100, 30, 440);
        col.fillRect(x - 10, 90, 50, 20);
        col.fillRect(x - 10, 530, 50, 20);
      }
    } else if (this.bossId === 'work-discrimination') {
      // Glass ceiling — horizontal line at y=300
      const ceil = this.add.graphics();
      ceil.fillStyle(parseInt(PALETTE.cobaltLight.replace('#','16'), 16), 0.5);
      ceil.fillRect(0, 290, 1280, 12);
      // Office windows
      for (let i = 0; i < 6; i++) {
        const x = 80 + i * 200;
        ceil.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
        ceil.fillRect(x, 100, 140, 180);
        ceil.fillStyle(parseInt(PALETTE.cobalt.replace('#','16'), 16), 0.7);
        ceil.fillRect(x + 4, 104, 132, 172);
      }
    } else {
      // Generic dark backdrop with blood red bars
      const g = this.add.graphics();
      g.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 0.4);
      g.fillRect(0, 80, 1280, 460);
    }
  }

  _buildHUD(w, h) {
    // Boss name in top bar
    this.bossNameText = this.add.text(20, 18, this.bossDef.name, {
      fontFamily: FONT.display,
      fontSize: '32px',
      color: PALETTE.paper,
      fontStyle: 'bold',
    });

    // Boss HP bar
    this.bossHpBg = this.add.graphics();
    this.bossHpBg.fillStyle(parseInt(PALETTE.bloodDeep.replace('#','16'), 16), 1);
    this.bossHpBg.fillRect(20, 56, 600, 8);
    this.bossHpFg = this.add.graphics();

    // Smasher HP (top right)
    this.smasherHpBg = this.add.graphics();
    this.smasherHpBg.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    this.smasherHpBg.fillRect(820, 18, 240, 16);
    this.smasherHpFg = this.add.graphics();
    this.smasherHpFg.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.smasherHpFg.fillRect(820, 18, 240, 16);

    // Truth meter (under smasher hp)
    this.truthBg = this.add.graphics();
    this.truthBg.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    this.truthBg.fillRect(820, 40, 240, 8);
    this.truthFg = this.add.graphics();

    // Counter-truth display (center bottom, transient)
    this.counterText = this.add.text(w / 2, h - 60, '', {
      fontFamily: FONT.display,
      fontSize: '48px',
      color: PALETTE.gold,
      fontStyle: 'bold',
      stroke: PALETTE.ink,
      strokeThickness: 4,
    });
    this.counterText.setOrigin(0.5);
    this.counterText.setAlpha(0);
  }

  _wireInput() {
    const k = this.input.keyboard;
    k.on('keydown-LEFT',  () => this.input.left = true);
    k.on('keydown-RIGHT', () => this.input.right = true);
    k.on('keydown-A',     () => this.input.left = true);
    k.on('keydown-D',     () => this.input.right = true);
    k.on('keyup-LEFT',    () => this.input.left = false);
    k.on('keyup-RIGHT',   () => this.input.right = false);
    k.on('keyup-A',       () => this.input.left = false);
    k.on('keyup-D',       () => this.input.right = false);

    k.on('keydown-J',     () => { this.input.strikePressed = true; });
    k.on('keydown-Z',     () => { this.input.strikePressed = true; });
    k.on('keydown-K',     () => { this.input.heavyPressed = true; });
    k.on('keydown-X',     () => { this.input.heavyPressed = true; });
    k.on('keydown-L',     () => { this.input.dashPressed = true; });
    k.on('keydown-C',     () => { this.input.dashPressed = true; });
    k.on('keydown-SHIFT', () => { this.input.blockHeld = true; this.input.blockPressed = true; });
    k.on('keyup-SHIFT',   () => { this.input.blockHeld = false; });
    k.on('keydown-SPACE', () => { this.input.truthBombPressed = true; });
  }

  update(t, dt) {
    dt = Math.min(dt, 0.05); // cap dt
    const dts = dt * 1000;

    this.smasher.update(this.input, dt);

    if (this.boss.alive) {
      this.boss.update(this.smasher, dt);
    }

    this.components.forEach(c => c.update(this.smasher, dt));
    this.components = this.components.filter(c => c.alive);

    // Projectiles
    this.projectiles.forEach(p => {
      p.text.x += p.dir * p.speed * dt;
      p.life -= dt;
      if (p.life <= 0 || p.text.x < 0 || p.text.x > 1280) {
        p.text.destroy();
        p.dead = true;
      } else if (this._hitsSmasher(p)) {
        this.smasher.takeDamage(p.damage, p.text.x);
        this._shatterProjectile(p);
        p.dead = true;
      }
    });
    this.projectiles = this.projectiles.filter(p => !p.dead);

    // Smash particles
    this.smashFx.forEach(fx => {
      fx.life -= dt;
      fx.text.x += fx.vx * dt;
      fx.text.y += fx.vy * dt;
      fx.text.alpha = Math.max(0, fx.text.alpha - dt);
      if (fx.life <= 0) { fx.text.destroy(); fx.dead = true; }
    });
    this.smashFx = this.smashFx.filter(fx => !fx.dead);

    // Hit collisions: player strike/heavy against boss & components
    this._resolvePlayerHits();

    // Reset edge-triggered input
    this.input.strikePressed = false;
    this.input.heavyPressed = false;
    this.input.dashPressed = false;
    this.input.blockPressed = false;
    this.input.truthBombPressed = false;

    // Update HUD
    this._updateHUD();

    // Victory check
    if (this.boss.shattered && this.components.length === 0 && !this.victoryStarted) {
      this._startVictory();
    }
  }

  _hitsSmasher(p) {
    if (this.smasher.iFrames > 0) return false;
    const sx = this.smasher.x, sy = this.smasher.y - 30;
    return Math.abs(p.text.x - sx) < 30 && Math.abs(p.text.y - sy) < 50;
  }

  _shatterProjectile(p) {
    for (let i = 0; i < 6; i++) {
      const shard = this.scene.add.text(p.text.x, p.text.y, p.text.text.slice(0,1), {
        fontFamily: FONT.display, fontSize: '24px', color: PALETTE.ink, fontStyle: 'bold',
      });
      shard.setOrigin(0.5);
      this.smashFx.push({
        text: shard, life: 0.5, dead: false,
        vx: (Math.random() - 0.5) * 200,
        vy: -100 - Math.random() * 80,
      });
    }
    p.text.destroy();
  }

  _resolvePlayerHits() {
    const targets = [];
    if (this.boss.alive) targets.push({ obj: this.boss, hb: this.boss, kind: 'boss' });
    this.components.forEach(c => targets.push({ obj: c, hb: { x: c.x, y: c.y, w: c.bodyW * 0.9, h: c.bodyH * 0.9 }, kind: 'comp' }));

    for (const { obj, hb, kind } of targets) {
      const hbs = [this.smasher.strikeHB, this.smasher.heavyHB];
      for (const hbPlayer of hbs) {
        if (!hbPlayer.active) continue;
        const overlap = this._aabb(hbPlayer, hb);
        if (overlap) {
          if (hbPlayer.hasHit.has(obj)) continue;
          hbPlayer.hasHit.add(obj);
          if (kind === 'boss') {
            const result = obj.takeHit(hbPlayer.damage);
            if (result.killed) this.smasher.gainTruth(40);
          } else {
            if (obj.takeHit(hbPlayer.damage)) this.smasher.gainTruth(20);
          }
        }
      }
    }
  }

  _aabb(a, b) {
    const ax = a.x, ay = a.y, aw = a.w || 0, ah = a.h || 0;
    const bx = b.x, by = b.y, bw = b.w || 40, bh = b.h || 40;
    return Math.abs(ax - bx) < (aw + bw) / 2 && Math.abs(ay - by) < (ah + bh) / 2;
  }

  _spawnProjectile(text, x, y, dir, damage, color, fontSize) {
    this.projectiles.push({
      text, x, y, dir, damage, color, fontSize,
      speed: 280,
      life: 5,
      dead: false,
    });
  }

  _flashCounterTruth(word, duration = 700) {
    this.counterText.setText(`+ ${word}`);
    this.counterText.setColor(PALETTE.gold);
    this.counterText.setAlpha(1);
    this.tweens.add({
      targets: this.counterText,
      alpha: 0,
      y: this.scale.height - 100,
      duration,
    });
  }

  _truthBombFx() {
    // Big red+gold ring expanding outward
    const ring = this.add.circle(this.smasher.x, this.smasher.y - 30, 30,
      parseInt(PALETTE.gold.replace('#','16'), 16), 0.6);
    ring.setStrokeStyle(6, parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    this.tweens.add({
      targets: ring,
      radius: 700,
      alpha: 0,
      duration: 700,
      onComplete: () => ring.destroy(),
    });

    // Destroy all projectiles & damage everything in range
    this.projectiles.forEach(p => { p.text.destroy(); p.dead = true; });
    this.components.forEach(c => {
      const d = Math.hypot(c.x - this.smasher.x, c.y - (this.smasher.y - 30));
      if (d < 400) c.takeHit(99);
    });
    if (this.boss.alive) {
      const d = Math.hypot(this.boss.x - this.smasher.x, this.boss.y - (this.smasher.y - 30));
      if (d < 400) this.boss.takeHit(40);
    }
  }

  _parryFx() {
    const ring = this.add.circle(this.smasher.x, this.smasher.y - 30, 10,
      parseInt(PALETTE.goldLight.replace('#','16'), 16), 0.8);
    this.tweens.add({
      targets: ring, radius: 80, alpha: 0, duration: 300,
      onComplete: () => ring.destroy(),
    });
  }

  _deathDefiedFx() {
    this.cameras.main.flash(400, 200, 29, 42, true);
    const txt = this.add.text(this.smasher.x, this.smasher.y - 80, 'I DON\'T LOSE TO THESE.', {
      fontFamily: FONT.display, fontSize: '32px', color: PALETTE.gold, fontStyle: 'bold',
      stroke: PALETTE.ink, strokeThickness: 4,
    });
    txt.setOrigin(0.5);
    this.tweens.add({
      targets: txt, y: this.smasher.y - 140, alpha: 0, duration: 1400,
      onComplete: () => txt.destroy(),
    });
  }

  _updateHUD() {
    // Boss HP
    this.bossHpFg.clear();
    const bossPct = Math.max(0, this.boss.hp / this.boss.maxHp);
    this.bossHpFg.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    this.bossHpFg.fillRect(20, 56, 600 * bossPct, 8);
    // Phase indicator
    if (this.boss.phase === 2) {
      this.bossHpFg.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
      this.bossHpFg.fillRect(220, 56, 4, 8);
    } else if (this.boss.phase === 3) {
      this.bossHpFg.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
      this.bossHpFg.fillRect(420, 56, 4, 8);
    }

    // Smasher HP
    this.smasherHpFg.clear();
    const sPct = this.smasher.hp / this.smasher.maxHp;
    this.smasherHpFg.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    this.smasherHpFg.fillRect(820, 18, 240 * sPct, 16);

    // Truth meter
    this.truthFg.clear();
    this.truthFg.fillStyle(parseInt(PALETTE.bloodLight.replace('#','16'), 16), 1);
    this.truthFg.fillRect(820, 40, 240 * (this.smasher.truthMeter / 100), 8);

    // Truth bomb indicator
    if (this.smasher.truthBombs > 0) {
      this.truthFg.fillStyle(parseInt(PALETTE.gold.replace('#','16'), 16), 1);
      this.truthFg.fillRect(820, 40, 240, 8);
    }
  }

  _startVictory() {
    this.victoryStarted = true;
    this.audio.stopMusic();
    this.audio.reveal();
    this.cameras.main.flash(400, 212, 160, 23, false);
    this.time.delayedCall(800, () => {
      this.smasher.setVictory();
      this.scene.start('Victory', { bossId: this.bossId });
    });
  }
}
