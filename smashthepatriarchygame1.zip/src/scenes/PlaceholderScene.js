// Placeholder scene for the 6 bosses not yet built.
// Shows the boss name big, the counter-truth, and a "coming soon" notice.

import Phaser from 'phaser';
import { PALETTE, FONT } from '../style/palette.js';
import { BOSSES } from '../data/bosses.js';

export class PlaceholderScene extends Phaser.Scene {
  constructor() { super('Placeholder'); }

  init(data) {
    this.bossId = data.bossId;
    this.boss = BOSSES.find(b => b.id === this.bossId);
  }

  create() {
    const { width, height } = this.scale;
    this.cameras.main.setBackgroundColor(PALETTE.paper);

    if (!this.boss) {
      this.scene.start('LevelSelect');
      return;
    }

    // Background banner
    const primary = parseInt((this.boss.palette?.primary || PALETTE.blood).replace('#','16'), 16);
    const g = this.add.graphics();
    g.fillStyle(primary, 1);
    g.fillRect(0, height * 0.25, width, height * 0.5);

    // Boss name huge
    this.add.text(width / 2, height * 0.4, this.boss.name, {
      fontFamily: FONT.display,
      fontSize: '120px',
      color: PALETTE.paper,
      fontStyle: 'bold',
      align: 'center',
      wordWrap: { width: width - 80 },
    }).setOrigin(0.5);

    // Counter-truth hint
    this.add.text(width / 2, height * 0.6, `counter-truth → ${this.boss.counterTruth}`, {
      fontFamily: FONT.body,
      fontSize: '24px',
      color: PALETTE.ink,
      fontStyle: 'bold',
    }).setOrigin(0.5);

    // Status
    this.add.text(width / 2, height * 0.66, 'this level is a placeholder — design complete, awaiting build', {
      fontFamily: FONT.body,
      fontSize: '16px',
      color: PALETTE.inkSoft,
      fontStyle: 'italic',
    }).setOrigin(0.5);

    // Component list
    const componentList = this.boss.components.map(c => c.word).join('  ·  ');
    this.add.text(width / 2, height * 0.74, componentList, {
      fontFamily: FONT.body,
      fontSize: '14px',
      color: PALETTE.blood,
      align: 'center',
      wordWrap: { width: width - 80 },
    }).setOrigin(0.5);

    // Back
    this.add.text(width / 2, height * 0.88, '[ENTER / CLICK] back to level select', {
      fontFamily: FONT.body,
      fontSize: '18px',
      color: PALETTE.ink,
    }).setOrigin(0.5);

    this.input.once('pointerdown', () => this.scene.start('LevelSelect'));
    this.input.keyboard.once('keydown-ENTER', () => this.scene.start('LevelSelect'));
  }
}
