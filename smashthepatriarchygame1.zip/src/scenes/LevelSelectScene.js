// Level select — all 7 bosses visible. Manosphere is fully playable;
// the others are placeholders (clicking them shows a title card).

import Phaser from 'phaser';
import { PALETTE, FONT } from '../style/palette.js';
import { BOSSES } from '../data/bosses.js';

export class LevelSelectScene extends Phaser.Scene {
  constructor() { super('LevelSelect'); }

  create() {
    const { width, height } = this.scale;
    this.cameras.main.setBackgroundColor(PALETTE.paper);

    this.add.text(width / 2, 50, 'CHOOSE YOUR FIGHT', {
      fontFamily: FONT.display,
      fontSize: '48px',
      color: PALETTE.ink,
      fontStyle: 'bold',
    }).setOrigin(0.5);

    // 7 cards in a row of 4 + 3
    const cardW = 240;
    const cardH = 280;
    const gap = 24;
    const startX = (width - (4 * cardW + 3 * gap)) / 2 + cardW / 2;
    const row1Y = 220;
    const row2Y = row1Y + cardH + 40;

    BOSSES.forEach((boss, i) => {
      const col = i % 4;
      const row = Math.floor(i / 4);
      const x = startX + col * (cardW + gap);
      const y = (row === 0 ? row1Y : row2Y);

      this._drawCard(boss, x, y, cardW, cardH);
    });

    // Back link
    const back = this.add.text(width / 2, height - 30, '[ESC] back to title', {
      fontFamily: FONT.body,
      fontSize: '16px',
      color: PALETTE.inkSoft,
    }).setOrigin(0.5);
    back.setInteractive({ useHandCursor: true });
    back.on('pointerdown', () => this.scene.start('Title'));
    this.input.keyboard.once('keydown-ESC', () => this.scene.start('Title'));
  }

  _drawCard(boss, x, y, w, h) {
    const g = this.add.graphics();
    const isPlayable = boss.playable;

    // Shadow plate (riso misregistration)
    g.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 0.6);
    g.fillRect(x - w/2 + 5, y - h/2 + 5, w, h);

    // Card body
    g.fillStyle(parseInt(PALETTE.ink.replace('#','16'), 16), 1);
    g.fillRect(x - w/2, y - h/2, w, h);

    // Inset primary color
    const primary = parseInt((boss.palette?.primary || PALETTE.blood).replace('#','16'), 16);
    g.fillStyle(primary, 1);
    g.fillRect(x - w/2 + 8, y - h/2 + 8, w - 16, h - 16);

    // Gold border
    g.lineStyle(3, parseInt(PALETTE.gold.replace('#','16'), 16), 1);
    g.strokeRect(x - w/2 + 14, y - h/2 + 14, w - 28, h - 28);

    // Boss number
    this.add.text(x, y - h/2 + 36, `#${BOSSES.indexOf(boss) + 1}`, {
      fontFamily: FONT.body,
      fontSize: '14px',
      color: PALETTE.paper,
    }).setOrigin(0.5);

    // Boss name
    this.add.text(x, y - 10, boss.name, {
      fontFamily: FONT.display,
      fontSize: '32px',
      color: PALETTE.paper,
      fontStyle: 'bold',
      align: 'center',
      wordWrap: { width: w - 32 },
    }).setOrigin(0.5);

    // Status
    const statusColor = isPlayable ? PALETTE.gold : PALETTE.cream;
    const statusText = isPlayable ? 'PLAY NOW' : 'COMING SOON';
    this.add.text(x, y + h/2 - 50, statusText, {
      fontFamily: FONT.body,
      fontSize: '14px',
      color: statusColor,
      fontStyle: 'bold',
    }).setOrigin(0.5);

    // Component count
    this.add.text(x, y + h/2 - 28, `${boss.components.length} components`, {
      fontFamily: FONT.body,
      fontSize: '12px',
      color: PALETTE.cream,
    }).setOrigin(0.5);

    // Make interactive
    const hit = this.add.rectangle(x, y, w, h, 0x000000, 0);
    hit.setInteractive({ useHandCursor: true });
    hit.on('pointerover', () => {
      this.tweens.add({ targets: g, alpha: 0.85, duration: 100 });
    });
    hit.on('pointerout', () => {
      this.tweens.add({ targets: g, alpha: 1, duration: 100 });
    });
    hit.on('pointerdown', () => this._select(boss));
  }

  _select(boss) {
    if (boss.playable) {
      this.scene.start('Game', { bossId: boss.id });
    } else {
      this.scene.start('Placeholder', { bossId: boss.id });
    }
  }
}
