// Boot scene — runs once at startup. Initializes audio (on first user gesture),
// loads the Smasher painting, then transitions to Title.

import Phaser from 'phaser';
import { AudioEngine } from '../audio/AudioEngine.js';

export class BootScene extends Phaser.Scene {
  constructor() { super('Boot'); }

  create() {
    // Create the audio engine. Browser policy: AudioContext must be created or
    // resumed on a user gesture. We create it here, and resume in Title on click.
    this.game.audio = new AudioEngine();
    this.game.audio.init();

    // Load the Smasher painting (Rebecca Wanzo). Vite will copy this into the build.
    if (this.textures.exists('smasher_idle')) {
      // Already loaded (e.g. HMR) — skip
    } else {
      this.load.image('smasher_idle', 'assets/smasher/idle.png');
    }

    // Load a paper-texture overlay (procedural) as a placeholder.
    this.load.on('complete', () => {
      this.scene.start('Title');
    });

    this.load.start();
  }
}
