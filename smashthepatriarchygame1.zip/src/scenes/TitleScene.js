// Title screen — bold poster art, full of attitude.
// Rebecca's painting sits as a poster element behind/around the title.

import Phaser from 'phaser';
import { PALETTE, FONT } from '../style/palette.js';

export class TitleScene extends Phaser.Scene {
  constructor() { super('Title'); }

  create() {
    const { width, height } = this.scale;

    // Resume audio context (must happen on user gesture)
    this.input.once('pointerdown', () => this.game.audio.resume());
    this.input.keyboard.once('keydown', () => this.game.audio.resume());

    // Backdrop
    this.cameras.main.setBackgroundColor(PALETTE.paper);

    // Big diagonal blood-red banner
    const banner = this.add.graphics();
    banner.fillStyle(parseInt(PALETTE.blood.replace('#','16'), 16), 1);
    banner.beginPath();
    banner.moveTo(0, height * 0.18);
    banner.lineTo(width, height * 0.05);
    banner.lineTo(width, height * 0.22);
    banner.lineTo(0, height * 0.35);
    banner.closePath();
    banner.fillPath();

    // Title — SMASH THE PATRIARCHY
    const title = this.add.text(width / 2, height * 0.18, 'SMASH', {
      fontFamily: FONT.display,
      fontSize: '120px',
      color: PALETTE.paper,
      fontStyle: 'bold',
    });
    title.setOrigin(0.5);
    title.setShadow(0, 6, PALETTE.ink, 12, true, true);

    const title2 = this.add.text(width / 2, height * 0.28, 'THE PATRIARCHY', {
      fontFamily: FONT.display,
      fontSize: '72px',
      color: PALETTE.ink,
      fontStyle: 'bold',
    });
    title2.setOrigin(0.5);

    // Painting as a poster on the right
    if (this.textures.exists('smasher_idle')) {
      const painting = this.add.image(width * 0.78, height * 0.62, 'smasher_idle');
      const target = height * 0.62;
      painting.setDisplaySize(target, target);
      // Gold frame
      const frame = this.add.graphics();
      frame.lineStyle(8, parseInt(PALETTE.gold.replace('#','16'), 16), 1);
      frame.strokeRect(painting.x - target/2 - 4, painting.y - target/2 - 4, target + 8, target + 8);
    }

    // Subtitle / tagline
    const tagline = this.add.text(width / 2, height * 0.46,
      'Each monster is a word. Break the word,\nand it shatters into the smaller things that made it.',
      {
        fontFamily: FONT.body,
        fontSize: '20px',
        color: PALETTE.ink,
        align: 'center',
        lineSpacing: 8,
      });
    tagline.setOrigin(0.5);

    // Press to play
    const prompt = this.add.text(width / 2, height * 0.92, '[ CLICK / ENTER TO BEGIN ]', {
      fontFamily: FONT.body,
      fontSize: '22px',
      color: PALETTE.blood,
      fontStyle: 'bold',
    });
    prompt.setOrigin(0.5);
    this.tweens.add({
      targets: prompt,
      alpha: 0.2,
      duration: 700,
      yoyo: true,
      repeat: -1,
    });

    // Controls hint
    const controls = this.add.text(width / 2, height * 0.85,
      'ARROWS / WASD  move   ·   J / Z  strike   ·   K / X  heavy   ·   L / C  dash\n' +
      'SHIFT  block   ·   SPACE  truth bomb',
      {
        fontFamily: FONT.body,
        fontSize: '16px',
        color: PALETTE.inkSoft,
        align: 'center',
        lineSpacing: 4,
      });
    controls.setOrigin(0.5);

    // Click / enter to begin
    this.input.once('pointerdown', () => {
      this.game.audio.resume();
      this.scene.start('LevelSelect');
    });
    this.input.keyboard.once('keydown-ENTER', () => {
      this.game.audio.resume();
      this.scene.start('LevelSelect');
    });
    this.input.keyboard.once('keydown-SPACE', () => {
      this.game.audio.resume();
      this.scene.start('LevelSelect');
    });
  }
}
