// All 7 boss definitions. The Manosphere is fully playable;
// the other 6 are placeholder scenes.

export const BOSSES = [
  {
    id: 'manosphere',
    name: 'MANOSPHERE',
    arena: 'A digital void, glowing screens everywhere',
    description: 'The networked lair of male supremacists online.',
    components: [
      { word: 'INCEL',            speed: 1.0, hp: 2, size: 38 },
      { word: 'RED PILL',         speed: 0.9, hp: 3, size: 46 },
      { word: 'MGTOW',            speed: 1.1, hp: 2, size: 40 },
      { word: 'PICKUP ARTIST',    speed: 0.8, hp: 3, size: 50 },
    ],
    counterTruth: 'SOLIDARITY',
    counterTruthBody: 'Isolated men taught to hate. The Smasher names them, breaks them apart.',
    playable: true,
    palette: { primary: '#1a3a8a', accent: '#c81d2a' },
    bossTaunts: [
      'You don\'t belong here.',
      'Logic. Reason. Hierarchy.',
      'You can\'t smash an idea.',
    ],
    victoryLine: 'It was always many things. Now it is broken things.',
  },

  {
    id: 'rape',
    name: 'RAPE',
    arena: 'A courthouse turned inside-out, broken gavels',
    description: 'Legal systems that fail survivors.',
    components: [
      { word: 'VICTIM BLAMING', speed: 1.0, hp: 2, size: 44 },
      { word: 'SLUT SHAMING',   speed: 1.1, hp: 2, size: 38 },
      { word: 'MARITAL RAPE',   speed: 0.9, hp: 3, size: 40 },
      { word: 'RAPE CULTURE',   speed: 0.8, hp: 4, size: 50 },
    ],
    counterTruth: 'CONSENT',
    counterTruthBody: 'A web of laws, lies, and silence. The Smasher tears it down.',
    playable: false,
    palette: { primary: '#1a1414', accent: '#c81d2a' },
  },

  {
    id: 'work-discrimination',
    name: 'WORK DISCRIMINATION',
    arena: 'A boardroom with a glass ceiling that cracks on hit',
    description: 'Wage theft in a necktie.',
    components: [
      { word: 'PAY GAP',        speed: 1.0, hp: 2, size: 38 },
      { word: 'GLASS CEILING',  speed: 0.9, hp: 3, size: 50 },
      { word: 'HIRING BIAS',    speed: 1.1, hp: 2, size: 42 },
      { word: 'HARASSMENT',     speed: 0.85, hp: 4, size: 48 },
    ],
    counterTruth: 'EQUITY',
    counterTruthBody: 'She breaks the ceiling with her hands. The office was never hers — she makes it so.',
    playable: false,
    palette: { primary: '#1a3a8a', accent: '#d4a017' },
  },

  {
    id: 'health-inequality',
    name: 'HEALTH INEQUALITY',
    arena: 'A clinic, walls of stethoscopes and IV bags',
    description: 'A system that doesn\'t see her pain.',
    components: [
      { word: 'MATERNAL MORTALITY',  speed: 0.9, hp: 4, size: 56 },
      { word: 'PAIN DISMISSAL',      speed: 1.1, hp: 2, size: 44 },
      { word: 'REPRODUCTIVE CONTROL',speed: 0.95, hp: 3, size: 52 },
    ],
    counterTruth: 'BELIEVE HER',
    counterTruthBody: 'They told her the pain was in her head. The Smasher makes them listen.',
    playable: false,
    palette: { primary: '#c81d2a', accent: '#1a1414' },
  },

  {
    id: 'motherhood-penalty',
    name: 'MOTHERHOOD PENALTY',
    arena: 'A factory floor that doubles as a nursery',
    description: 'Work that punishes the work of caring.',
    components: [
      { word: 'WAGE PENALTY',    speed: 1.0, hp: 2, size: 42 },
      { word: 'CARE PENALTY',    speed: 1.0, hp: 2, size: 40 },
      { word: 'PINK COLLAR',     speed: 0.9, hp: 3, size: 44 },
      { word: 'BUMP PENALTY',    speed: 1.1, hp: 2, size: 38 },
    ],
    counterTruth: 'WORTH HER WORK',
    counterTruthBody: 'The cost of caring is uncountable. The Smasher charges it anyway.',
    playable: false,
    palette: { primary: '#d4a017', accent: '#c81d2a' },
  },

  {
    id: 'femicide',
    name: 'FEMICIDE',
    arena: 'A streetlamp-lit alley that grows into a vigil',
    description: 'The price of being a woman in the wrong place.',
    components: [
      { word: 'MISOGYNOIR',          speed: 0.95, hp: 3, size: 50 },
      { word: 'DOMESTIC VIOLENCE',   speed: 0.9, hp: 3, size: 52 },
      { word: 'HONOR KILLING',       speed: 1.0, hp: 2, size: 44 },
      { word: 'SILENCE = DEATH',     speed: 0.85, hp: 4, size: 56 },
    ],
    counterTruth: 'SHE LIVED',
    counterTruthBody: 'For the ones who didn\'t. For the ones who still do. The Smasher names them.',
    playable: false,
    palette: { primary: '#1a1414', accent: '#c81d2a' },
  },

  {
    id: 'gender-essentialism',
    name: 'GENDER ESSENTIALISM',
    arena: 'A dollhouse that is also a boxing ring',
    description: 'The oldest boss. The one that taught the others to speak.',
    components: [
      { word: 'PINK / BLUE',              speed: 1.0, hp: 2, size: 40 },
      { word: 'HOUSEWIFE MYTH',           speed: 0.9, hp: 3, size: 46 },
      { word: 'BIOLOGICAL DETERMINISM',   speed: 0.95, hp: 3, size: 56 },
      { word: '"JUST A GIRL"',            speed: 1.1, hp: 2, size: 44 },
    ],
    counterTruth: 'I AM / I CHOOSE',
    counterTruthBody: 'The boss of bosses. Not a wall — a question. The Smasher answers it.',
    playable: false,
    isFinal: true,
    palette: { primary: '#c81d2a', accent: '#d4a017' },
  },
];
